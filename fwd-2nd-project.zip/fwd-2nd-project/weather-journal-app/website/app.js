/* Global Variables */
const apiKey = "6b1bae9ca1bc59a61d55f14e554a3606";
const btn = document.querySelector("#generate");
const feel = document.getElementById("feelings");

// Create a new date instance dynamically with JS
let d = new Date();

//adding one as it starts from zero
let newDate = d.getMonth() + 1 + "." + d.getDate() + "." + d.getFullYear();

//generating data 
btn.addEventListener("click", async function () {
  try {
    const data = await gettingTempData();
    console.log(data);
    const send_data = await postingTempData({
      data: data,
      temp: data.main.temp,
      feelings: feel,
    });
    
    console.log(send_data);
    await updateUI();
  } catch (err) {
    console.log(err);
  }
});
//getting the temperature of the required region with the entered zipcode
async function gettingTempData() {
  const zipCode = document.getElementById("zip").value;
  const wUrl = `https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}&appid=${apiKey}&units=metric`;

  try {
    const resData = await fetch(wUrl);
    const response = await resData.json();
    return response;
  } catch (error) {
    console.log(error);
  }
}

// post the data to the server
async function postingTempData({ data, temp, feelings }) {
  //fetching route url
  await fetch("/postingData", {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      temp: temp,
      date: data,
      feelings: feelings.value,
    }),
  });
  //recieving data
  try {
    const reqData = await fetch("/gettingData");
    const req1 = await reqData.json();
    return req1;
  } catch (error) {
    console.log(error);
  }
}

//getting data from server and updateUI
async function updateUI() {
  const req2 = await fetch("/gettingData");

  try {
    const data = await req2.json();

    document.getElementById("temp").innerHTML = data.temp;
    document.getElementById("date").innerHTML = getDate();
    document.getElementById("content").innerHTML = data.feelings;
    console.log("====================================");
    console.log(data.date);
    console.log("====================================");
    
    
  } catch (error) {
    console.log(error);
  }
}

const getDate = () => {
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
  var yyyy = today.getFullYear();

  today = dd + "/" + mm + "/" + yyyy;
  return today;
};
